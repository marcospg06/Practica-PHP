<?php
//dados del jugador 1

echo "<h1>Jugador 1</h1>";

$p1d1 = rand(1,6);
$p1d2 = rand(1,6);
$p1d3 = rand(1,6);
$p1d4 = rand(1,6);
$p1d5 = rand(1,6);

    print "<p>";
    print "<img src = '../PRACTICA-PHP/img/$p1d1.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p1d2.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p1d3.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p1d4.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p1d5.jpg' height=140>";
    print "</p>";
//dados para el jugador 2

echo "<h1>Jugador2</h1>";

$p2d1 = rand(1,6);
$p2d2 = rand(1,6);
$p2d3 = rand(1,6);
$p2d4 = rand(1,6);
$p2d5 = rand(1,6);


    print "<p>";
    print "<img src = '../PRACTICA-PHP/img/$p2d1.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p2d2.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p2d3.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p2d4.jpg' height=140>";
    print "<img src = '../PRACTICA-PHP/img/$p2d5.jpg' height=140>";
    print "</p>";
    
    $totalp1 = $p1d1 + $p1d2 + $p1d3 + $p1d4 + $p1d5;
    $totalp2 = $p2d1 + $p2d2 + $p2d3 + $p2d4 + $p2d5;

    if($totalp1 === $totalp2){
        print "Los jugadores han empatado";
    }elseif($totalp1 > $totalp2){
        print "El jugador 1 ha ganado";
    }else{
        print "El jugador 2 ha ganado";
    }
