<?php
    $alto = $_REQUEST["alto"];
    $ancho = $_REQUEST["ancho"];

    print "<h1>Cuadrado con *</h1>";

    print "Alto : $alto" . "<br>" . "Ancho : $ancho" . "<br><br>";

    for($i = 1;$i <= $alto; $i++){
        for($j = 1;$j <= $ancho; $j++){
            print "* ";
        }
        print "<br>";
    }
    
?>