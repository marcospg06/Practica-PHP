<?php
$nombre = $_POST['nombre'];
//print "El nombre introducido es: $nombre <br>";
 
$telefono = $_POST['telefono'];
//print "El telefono introducido es: $telefono <br>";
 
$matricula = isset($_POST['matricula']); //isset te devuelve true o false
if($matricula){
    $matriculado = 'matriculado';
}else{
    $matriculado = 'no matriculado';
}

//print "El estado de la matricula esta: $matriculado <br>";
 
$mostrar = $_POST['datos'];
//print "Los datos se mostraran por: $mostrar <br>";
 
$estudios = $_POST['estudios'];
//print "Los estudios seleccionados son: $estudios <br>";
 
$mensaje = "El alumno $nombre con telefono $telefono, esta $matriculado en un $estudios";
//print "$mensaje";
 
if($mostrar == "pantalla"){
    print "$mensaje";
}
elseif($mostrar == "txt"){
    if(file_exists("datos.txt")){
        file_put_contents("datos.txt",$mensaje);
    }
    else{
        fopen("datos.txt", 'w'); //es solo modo escritura
        fwrite("datos.txt",'$mensaje');
        fclose("datos.txt");
    }
    print "<a href='mostrardatos.php'>Mostrar Archivo</a>";
}
 
?>