<?php
// mostrardatos.php
 
// Nombre del archivo donde se guardaron los datos
$archivo = "datos.txt";
 
// Comprobar si el archivo existe
if (file_exists($archivo)) {
    // Abrir el archivo en modo lectura
    $contenido = file_get_contents($archivo);
   
    // Mostrar su contenido en el navegador
    print "<h1>Contenido del archivo de alumnos:</h1>";
    print "<pre>$contenido</pre>"; // <pre> mantiene el formato de texto
} else {
    // Si no existe, mostrar un mensaje de error
    print "<p style='color:red;'>El archivo datos.txt no existe o aún no se han guardado datos.</p>";
}
?>