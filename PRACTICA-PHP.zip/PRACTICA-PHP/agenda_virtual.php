<?php
//dar de alta
$accion = $_POST['modo'];
//print "$accion";
//declaramos variables
$nombre = $_POST['nombre'];
print "El nombre es $nombre, ";
 
$trabajo = $_POST['trabajo'];
print "cuyo trabajo es $trabajo, ";
 
$telefono = $_POST['telefono'];
print "con telefono $telefono, ";
 
$direccion = $_POST['direccion'];
print "con direccion $direccion, ";
 
$otras = $_POST['otras'];
print "$otras <br>";
 
if($accion == 'Guardar'){
    $linea = "$nombre;$trabajo;$telefono;$direccion;$otras";
    $fichero = fopen("contacto.txt", 'w');
    fwrite($fichero, $linea);
    fclose($fichero);
}
print "<a href='mostraragenda.php'>Mostrar Agenda</a>";
?>